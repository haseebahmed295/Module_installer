This addon alows user to install extension using Python wheels
